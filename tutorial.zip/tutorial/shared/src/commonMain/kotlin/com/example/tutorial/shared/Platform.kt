package com.example.tutorial.shared

expect class Platform() {
    val platform: String
}